<?php
$GLOBALS['aliasmailSettings'] = [
    'MAIL_USER' => base64_decode('YWRtaW5AbmV4dGVybmNvbnN1bHRhbmN5LmNvbQ=='),
    'MAIL_PASSWORD' => base64_decode('V2hlcmV5b3UnbGwxMjM0QA=='),
    'MAIL_BRIDGE_TOKEN' => base64_decode('Q2NyeHhQR19ub2QyLWJwMGVSQmswRXNQTHdNbTE5NUw2TnFxZWgzcFJUTQ=='),
    'IMAP_HOST' => base64_decode('aW1hcC5zZWN1cmVzZXJ2ZXIubmV0'),
    'IMAP_PORT' => base64_decode('OTkz'),
    'IMAP_SECURE' => base64_decode('dHJ1ZQ=='),
    'SMTP_HOST' => base64_decode('c210cG91dC5zZWN1cmVzZXJ2ZXIubmV0'),
    'SMTP_PORT' => base64_decode('NDY1'),
    'SMTP_SECURE' => base64_decode('dHJ1ZQ=='),
    'SMTP_AUTH' => base64_decode('dHJ1ZQ=='),
    'MAIL_INBOX_FOLDER' => base64_decode('SU5CT1g='),
    'MAIL_SENT_FOLDER' => base64_decode('U2VudA=='),
    'MAIL_SPAM_FOLDER' => base64_decode('SnVuaw=='),
    'MAIL_TRASH_FOLDER' => base64_decode('VHJhc2g='),
];
